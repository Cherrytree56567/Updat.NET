# Updat.NET-Updates
Updat.NET Updates is a repository that holds the Antivirus Definitions Updates for Updat.NET 

# Thanks to
* Reversing Labs
* Yara-Rules
